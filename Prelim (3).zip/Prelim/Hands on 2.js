class Book{
    constructor(title,author,publicationyear){
        this.title = title;
        this.author = author;
        this.publicationyear = publicationyear;
    }
    displayDetails(){
        console.log(`title : ${this.title}`);
        console.log(`author : ${this.author}`);
        console.log(`publicationYear : ${this.publicationyear}`);
    }
}

class Ebook extends Book{
    constructor(title,author,publicationyear,price){
        super(title,author,publicationyear,);
        this.price = price;
}
displayDetails(){
    super.displayDetails();
    console.log(`Price : ${this.price}`);
}
}
const ebook1 = new Ebook('The attachment Style','Ria Martez',2024 ,'$300.9');
const ebook2 = new Ebook('Harry Potter','JK Rowling' ,1900, '$1908');
const ebook3 = new Ebook('Book3','author 2',1988 ,'$25.33');

ebook1.displayDetails();
console.log('\n');
ebook2.displayDetails();
console.log('\n');
ebook3.displayDetails();

